﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vecter3DTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Vector3D a = new Vector3D(1.0,2.0,3.0);
            Vector3D b = new Vector3D(-1.0, 3.0, 2.0);

            Vector3D c = a + b;       //합
            Vector3D d = a - b;       //차
            Vector3D e = 3.0 * a;     // 스칼라곱
            Vector3D f = a * 3.0;     // 스칼라곱
            Vector3D g = a / 3.0;     // 스칼라 나누기
            double h = a * b;         // 내적
            double i = a.Magnitude(); // 유닛벡터화
            Vector3D j = a | b;       // 외적
        }
    }
}
