﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vecter3DTest
{
    class Vector3D
    {
        double mX;
        double mY;
        double mZ;

        public Vector3D(double x, double y, double z)
        {
            mX = x;
            mY = y;
            mZ = z;
        }
        public double Magnitude()
        {
            return Math.Sqrt(this * this);
        }

        public Vector3D getNormalize()
        {
            return this / Magnitude();
        }

        public static Vector3D operator +(Vector3D a, Vector3D b)
        {
            Vector3D result = new Vector3D(a.mX + b.mX, a.mY + b.mY, a.mZ + b.mZ);
            return result;
        }

        public static Vector3D operator -(Vector3D a, Vector3D b)
        {
            Vector3D result = new Vector3D(a.mX - b.mX, a.mY - b.mY, a.mZ - b.mZ);
            return result;
        }

        public static Vector3D operator *(double a, Vector3D b)
        {
            Vector3D result = new Vector3D(a * b.mX, a * b.mY, a * b.mZ);
            return result;
        }

        public static Vector3D operator *(Vector3D b, double a)
        {
            Vector3D result = new Vector3D(a * b.mX, a * b.mY, a * b.mZ);
            return result;
        }

        public static Vector3D operator /(Vector3D a, double b)
        {
            Vector3D result = new Vector3D(a.mX/b, a.mY/b, a.mZ/b);
            return result;
        }

        public static double operator *(Vector3D a, Vector3D b)
        {
            double result = a.mX * b.mX + a.mY * b.mY + a.mZ * b.mZ;
            return result;
        }

        public static Vector3D operator |(Vector3D a, Vector3D b)
        {
            Vector3D result = new Vector3D((a.mY * b.mZ) - (a.mZ * b.mY), -((a.mX * b.mZ) - (a.mZ * b.mX)), (a.mX * b.mY) - (a.mY * b.mX));
            return result;
        }
        
    }
}
