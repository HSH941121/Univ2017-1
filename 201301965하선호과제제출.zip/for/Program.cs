﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @for
{
    class Program
    {
        static double Sum(double input)
        {
            double r = 0.9;
            double result = 0;
            for(int i = 0; i < input; i++)
            {
                result += Math.Pow(r, i);
            }
            return result;
        }
        static void Main(string[] args)
        {
            double a = Sum(100);
            Console.WriteLine(a);
            Console.ReadKey();
            /*출력값:9.99973438601112
             * S=1/1-r=10
             * 거의 비슷하게 출력됨.
             */
        }
    }
}
