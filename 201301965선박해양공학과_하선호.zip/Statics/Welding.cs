﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Statics
{
    class Welding : Boundary_Condition
    {
        public override void Calculate()
        {
            Console.WriteLine("용접된 부분의 경계조건은 X축과 Y축의 반력 그리고 모멘트가 발생합니다.");
        }
        public Welding(double x,double y,double m) : base(x, y, m)
        {

        }
    }
}
