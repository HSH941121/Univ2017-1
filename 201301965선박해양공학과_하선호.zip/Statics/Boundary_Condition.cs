﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Statics
{
    abstract class Boundary_Condition
    {
        double Fx;
        double Fy;
        double Moment;

        public Boundary_Condition(double x,double y,double m)
        {
            Fx = x;
            Fy = y;
            Moment = m;
        }
        abstract public void Calculate();
    }
}
