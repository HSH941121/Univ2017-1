﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Statics
{
    class Roller : Boundary_Condition
    {
        public override void Calculate()
        {
            Console.WriteLine("롤러 경계조건은 Y축 반력만 존재 합니다.");
        }
        public Roller(double x, double y, double m) :base(x,y,m)
        {

        }
    }
}
