﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Statics
{
    class Hinge : Boundary_Condition
    {
        public Hinge(double x, double y, double m) : base(x, y, m)
        {

        }
        public override void Calculate()
        {
            Console.WriteLine("힌지 경게조건은 X축과 Y축 반력이 존재 합니다.");
        }
    }
}
