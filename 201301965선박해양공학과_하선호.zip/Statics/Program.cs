﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Statics
{
    class Program
    {
        static void Main(string[] args)
        {
            Boundary_Condition[] Boundary = new Boundary_Condition[3];

            Boundary_Condition RollerA = new Roller(10, 0, 0);
            Boundary_Condition HingeA = new Hinge(10, 10, 0);
            Boundary_Condition WeldingA = new Welding(10, 10, 10);

            Boundary[0] = RollerA;
            Boundary[1] = HingeA;
            Boundary[2] = WeldingA;

            for(int i = 0; i < Boundary.Length; i++)
            {
                Boundary[i].Calculate();
            }
            Console.ReadKey();
        }
    }
}
