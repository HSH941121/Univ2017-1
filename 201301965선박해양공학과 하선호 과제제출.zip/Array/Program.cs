﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    class Program
    {
        static double[,] MVProduct(double[,] a, double[,] b)
        {
            double[,] result = new double[a.GetLength(0), b.GetLength(0)];
            if(a.GetLength(1) != b.GetLength(0))
            {
                throw new Exception();
            }
            for(int i = 0;i <a.GetLength(1); i++)
            {
                double sum1 = 0.0;
                double sum2 = 0.0;
                for(int j = 0; j<a.GetLength(1); j++)
                {
                    for(int k = 0; k< a.GetLength(0); k++)
                    {
                        sum1 += a[i, j] * b[i,j];
                        sum2 += a[i, k] * b[i, k];
                    }
                }
                result = [sum1, sum2];
            }
            return result;
        }
        static void Main(string[] args)
        {
            double[,] a = new double[2, 3]
                {
                    {1.0,2.0,3.0 },
                    { 3.0,2.0,1.0}  
                };
            double[,] b = new double[3, 2]
            {
                { 1.0,2.0},
                { 3.0,4.0},
                {0.0,0.0 }

            };
            double [,]c = MVProduct(a, b);
        }
    }
}
