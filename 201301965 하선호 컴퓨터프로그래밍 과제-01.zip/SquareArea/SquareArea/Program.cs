﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SquareArea
{
    class Program
    {
        static double SquareArea(double A,double B)
        {
            double area = A * B;
            return area;
        }
        static void Main(string[] args)
        {
            double a;
            double b;
            double area;
            Console.WriteLine("안녕하세요. 본 프로그램은 직사각형의 넓이를 구해주는 프로그램입니다.");
            Console.WriteLine("가로길이를 입력해주세요!!");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("세로길이를 입력해주세요!!");
            b = double.Parse(Console.ReadLine());
            area = SquareArea(a, b);
            Console.WriteLine("사각형의 넓이는 {0}입니다~", area);
            Console.ReadKey();
        }
    }
}
