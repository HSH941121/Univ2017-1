﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleArea
{
    class Program
    {
        static double CircleArea(double r)
        {
            double area = Math.PI * Math.Pow(r, 2);
            return area;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("안녕하세요. 본 프로그램은 원의 넓이를 구하는 프로그램입니다.");
            Console.WriteLine("반지름을 입력하세요!!!");
            double radius = double.Parse(Console.ReadLine());
            double area = CircleArea(radius);
            Console.WriteLine("면적은 {0} 입니다~~", area);
            Console.ReadKey();
        }
    }
}
