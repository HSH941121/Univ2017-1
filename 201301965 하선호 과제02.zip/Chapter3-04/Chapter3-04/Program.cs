﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3_04
{
    class Program
    {
        static void Main(string[] args)
        {
            int m;
            Console.WriteLine("안녕하세요. 숫자를 입력하시면 짝수인지 홀수인지 판별해드립니다.");

            Console.Write("정수 숫자를 입력해주세요!  입력: ");
            m = int.Parse(Console.ReadLine());
            if(m%2 == 1)
            {
                Console.WriteLine("홀수 입니다!");
            }
            else
            {
                Console.WriteLine("짝수 입니다!");
            }
            Console.ReadKey();
        }
    }
}
