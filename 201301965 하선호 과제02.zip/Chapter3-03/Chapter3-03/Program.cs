﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3_03
{
    class Program
    {
        static void Main(string[] args)
        {
            int myAge = 39;
            Console.WriteLine("I am: {0} years old",myAge++);
            Console.ReadKey();
            /* 수행결과
             *  I am 39 years old
             */
        }
    }
}
