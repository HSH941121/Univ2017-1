﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3_02
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 5, y = 3;

            int z = x / y;
            Console.WriteLine("z: {0}", z);
            double a = (double)x;
            double b = (double)y;
            double c = a / b;
            Console.WriteLine("c: {0}", c);
            Console.ReadKey();
            /* 실행한 결과
             * z:1
             * c:1.6666666666667
             */
        }
    }
}
