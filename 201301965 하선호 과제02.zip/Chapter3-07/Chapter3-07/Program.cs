﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3_07
{
    class Program
    {
        static void Main(string[] args)
        {
            int myAge = 25;
            Console.WriteLine("I am {0} years old",myAge++);
            Console.WriteLine("You are {0} years old",++myAge);
            Console.WriteLine("She is {0} years old",--myAge);
            Console.WriteLine("He is {0} years old",myAge--);
            Console.ReadKey();
            /* 수행결과
             * 25
             * 27
             * 26
             * 26
             */ 
        }
    }
}
