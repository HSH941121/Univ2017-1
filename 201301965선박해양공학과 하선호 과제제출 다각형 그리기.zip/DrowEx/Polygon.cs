﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace DrowEx
{
    class Polygon :Shape
    {

        
        PointF[] a = new PointF[0];

        public Polygon(int w, Color c) :base(w,c)
        {

        }

        public override void Draw(Graphics g)
        {
            g.DrawPolygon(new Pen(mColor, mWidth),a);
        }
    }
}
