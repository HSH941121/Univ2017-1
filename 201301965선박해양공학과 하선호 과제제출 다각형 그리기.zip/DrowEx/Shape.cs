﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace DrowEx
{
    abstract class Shape
    {
        protected Color mColor;
        protected int mWidth;
        
        public Shape(int w, Color c)
        {
            mWidth = w;
            mColor = c;
        }

        public abstract void Draw(Graphics g);
        
    }
}
