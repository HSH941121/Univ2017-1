﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace DrowEx
{
    class Quadrangle :Shape
    {
        int mX;
        int mY;
        int mRWidth;
        int mHeight;

        public Quadrangle(int w, Color c, int x, int y, int rW, int h) :base(w,c)
        {
            mX = x;
            mY = y;
            mRWidth = rW;
            mHeight = h;
        }

        public override void Draw(Graphics g)
        {
            g.DrawRectangle(new Pen(mColor, mWidth),mX,mY,mRWidth,mHeight);
        }
    }
}
